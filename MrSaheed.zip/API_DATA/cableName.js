const cableName = [
  {
    id: 1,
    name: "GOTV",
  },
  {
    id: 2,
    name: "DSTV",
  },
  {
    id: 3,
    name: "STARTIME",
  },
];
module.exports = {cableName}