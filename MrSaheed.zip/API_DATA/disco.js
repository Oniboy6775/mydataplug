const disco = [
  {
    id: 18,
    name: "Ikeja Electric",
  },
  {
    id: 19,
    name: "Ibadan Electric",
  },
  {
    id: 20,
    name: "Eko Electric",
  },
  {
    id: 21,
    name: "Port Harcourt Electric",
  },
  {
    id: 22,
    name: "Kaduna Electric",
  },
  {
    id: 23,
    name: "Kano Electric",
  },
  {
    id: 24,
    name: "Jos Electric",
  },
  {
    id: 25,
    name: "Abuja Electric",
  },
];
module.exports = { disco };
