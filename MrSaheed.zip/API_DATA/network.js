const network = [
  {
    id: 1,
    name: "MTN",
  },
  {
    id: 2,
    name: "GLO",
  },
  {
    id: 3,
    name: "AIRTEL",
  },
  {
    id: 6,
    name: "9MOBILE",
  },
];
module.exports = { network };
